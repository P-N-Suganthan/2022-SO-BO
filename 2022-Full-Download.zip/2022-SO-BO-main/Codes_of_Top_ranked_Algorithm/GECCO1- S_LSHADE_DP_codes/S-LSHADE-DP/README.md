# S-LSHADE-DP

This repository contains the implementation of the S-LSHADE-DP algorithm from the paper:

Le Van Cuong, Nguyen Ngoc Bao, Nguyen Khanh Phuong, and Huynh Thi Thanh Binh. 2022. Dynamic Perturbation for Population Diversity Management in Differential Evolution. In Genetic and Evolutionary Computation
Conference Companion (GECCO ’22 Companion), July 9–13, 2022, Boston, MA, USA. ACM, New York, NY, USA, 4 pages. https://doi.org/10.1145/3520304.3529075